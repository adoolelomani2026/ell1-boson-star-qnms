RELATIVISTIC RADIAL MODES OF ELL=1 BOSON STARS
Presentation package - version 0.3.1

Start here
----------
Boson_Star_Radial_Preprint_v0.3.1.pdf

This is a conventionally paginated, single-column A4 working preprint modeled on the
author-submitted journal-manuscript format. It contains the scientific narrative,
numbered equations, publication tables, six vector figures, declarations,
technical appendices, references, and explicit gate decisions.

Scientific status
-----------------
- The relativistic radial benchmark is certified by two numerical methods.
- Gate A for the background remains open pending an independent shooting solve
  and resolution of the R99 versus R999 radius-definition discrepancy.
- The ordinary ell=0 QNM benchmark and production nonradial modes remain future
  milestones; the manuscript does not claim that they are complete.

Reproducibility
---------------
The Reproducibility directory contains the LaTeX source, the deterministic build
script, machine-readable certification data, and pinned environment files.

Build from the repository root with:
    python paper/build_preprint.py

Verification at packaging
-------------------------
- 20 automated tests passed.
- The PDF compiled in three LaTeX passes with resolved cross-references.
- All 14 rendered pages were visually inspected.
- Page format: A4.

Author: Adel H. Al-Yoorby, Department of Physics, Khalifa University of
Science and Technology. ORCID: 0009-0000-1935-4392.
